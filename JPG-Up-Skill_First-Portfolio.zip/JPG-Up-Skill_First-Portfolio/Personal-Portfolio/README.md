# My Personal Portfolio Website

## About My Project

This is my personal portfolio website made using HTML and CSS.

The website shows information about me, my skills, my projects, and my contact details.

I created this project to practice making a static website and to improve my HTML and CSS skills.

## Website Sections

### Home

The Home page is the main page of the website.

It contains:
- My name
- A short introduction
- Navigation menu
- Buttons that connect to other pages
- A code-style design

### About

The About page contains information about me.

It includes:
- My profile picture
- My name
- My description
- My interests
- What I am currently learning

The profile picture is added using the HTML image tag.

Example:

```html
<img src="zed.png" alt="Profile Picture" class="profile-image">
```

### Skills

The Skills page shows the skills that I am currently learning.

These include:
- HTML
- CSS
- C++

It also shows some projects that I have practiced.

The skills are displayed using cards.

### Contact

The Contact page contains my contact information.

It includes:
- Email
- Phone number
- Location
- Name input
- Email input
- Message box
- Send Message button

## CSS Features

I used CSS to design the website.

Some of the CSS features I used are:

- CSS variables
- Flexbox
- CSS Grid
- Hover effects
- Borders
- Shadows
- Responsive design
- Media queries

I used red as the main color of the website.

## Navigation

The navigation menu allows users to move between the different pages.

Example:

```html
<a href="about.html">About</a>
```

When the About link is clicked, it opens the About page.

## Hover Effects

I added hover effects to buttons, cards, and navigation links.

Example:

```css
.profile-card:hover {
    transform: translateY(-8px);
    border-color: var(--red);
}
```

This makes the card move upward when the mouse is placed over it.

## Responsive Design

I used media queries so the website can adjust to smaller screens.

Example:

```css
@media (max-width: 600px) {
}
```

This helps the website look better on phones and smaller screens.

## How to Run the Website

1. Open the project folder.
2. Open `home.html`.
3. The website will open in a web browser.
4. Use the navigation menu to visit the About, Skills, and Contact pages.

## What I Learned

Through this project, I learned how to:

- Create webpages using HTML
- Style webpages using CSS
- Use Flexbox and CSS Grid
- Add hover effects
- Create responsive webpages